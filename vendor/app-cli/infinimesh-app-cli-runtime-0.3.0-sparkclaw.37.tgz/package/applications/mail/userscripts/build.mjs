import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {installOutlookAccountIdentity} from './lib/outlook-account.mjs';
import {installOutlookEarlyBridge} from './lib/outlook-early-bridge.mjs';
import {installOutlookTransport} from './lib/outlook-transport.mjs';
import {installOutlookRangeTransport} from './lib/outlook-range.mjs';
import {installOutlookOriginalResolver} from './lib/outlook-original.mjs';
import {parseOutlookFolders} from './lib/outlook-folders.mjs';
import {installQQSendmailV1,qqPlainTextHTML,qqSendmailSid,qqTimeZone} from './lib/qq-sendmail-v1.mjs';
import {installReader} from './lib/reader-core.mjs';
import {gmailOriginalURL} from './lib/gmail-download.mjs';
import {parseGmailList,parseGmailReceivedList} from '../lib/gmail-list.mjs';
import {parseOutlookList} from '../lib/outlook-list.mjs';
import {parseQQMailList} from '../lib/qqmail-list.mjs';
import {markQQMailRead} from './lib/qqmail-mark-read.mjs';
import {providerAccountDOM} from '../lib/provider-account.mjs';

const root = new URL('../../../', import.meta.url);
const definitions = [
  {provider:'qq_mail', installNativeSend:installQQSendmailV1, file:'qq-mail-reader.user.js', label:'QQ Mail', uuid:'5b4323dc-326f-4fbb-a1a0-4ac8c00631c0', origins:['https://wx.mail.qq.com'],
   account:()=>document.querySelector('.frame-header .profile-user-info .user-email')?.textContent?.trim()||'',
   listURL:u=>u.pathname==='/list/maillist',
   parse:value=>(parseQQMailList(value)?.rows??[]).map(row=>({...row,draft:false,sent:row.folder==='sent',grouped:/^(?:C|@)/.test(row.provider_message_id)})),
   download:({id,row,binding})=>{if(!binding||row.grouped)return null;const u=new URL('/read/readmail',location.origin);u.searchParams.set('func','5');u.searchParams.set('mailid',id);u.searchParams.set('sid',binding.searchParams.get('sid'));return u;},
   markRead:markQQMailRead,
  },
  {provider:'gmail', file:'gmail-mail-reader.user.js', label:'Gmail', uuid:'1b57e83c-a914-48c1-a490-77d4bca191d5', origins:['https://mail.google.com'],
   account:()=>providerAccountDOM('gmail').account_address||'',
   listURL:u=>/^\/sync\/u\/\d+\/i\/bv$/.test(u.pathname),
   search:query=>{location.hash='#search/'+encodeURIComponent(query);},
   download:gmailOriginalURL,
   parse:parseGmailReceivedList,
   markRead:()=>null,
  },
  {provider:'outlook', accountIdentity:installOutlookAccountIdentity, parseFolders:parseOutlookFolders, parseConversations:value=>parseOutlookList(value,true), installTransport:installOutlookTransport, file:'outlook-mail-reader.user.js', label:'Outlook', uuid:'c2b90f5c-629d-41bd-8fc8-179729ad70b4', origins:['https://outlook.live.com','https://outlook.office.com','https://outlook.office365.com'],
   account:()=>{const roots=[...document.querySelectorAll('[role="tree"] [role="treeitem"][aria-level="1"][data-folder-name]')];const addresses=roots.map(n=>{const title=n.getAttribute('title')||'';return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(title)&&[...n.querySelectorAll(':scope > span')].some(child=>child.textContent.trim().toLowerCase()===title.toLowerCase())?title:'';}).filter(Boolean);return addresses.length===1?addresses[0]:document.querySelector('#mectrl_currentAccount_secondary')?.textContent?.trim()||'';},
   listURL:u=>/^\/owa\/\d+\/(?:startupdata\.ashx|service\.svc)$/.test(u.pathname),
   parse:value=>parseOutlookList(value,true).flatMap(row=>row.members?.map(member=>({...member,provider_thread_id:row.provider_selection_id,provider_selection_id:row.provider_selection_id,...(row.members.length===1?{received_at:row.last_delivery_time}:{}),sent:!member.local}))??(row.provider_message_id?[{...row,received_at:row.last_delivery_time,draft:false,sent:false}]:[])),
   markRead:()=>null,
  },
];
const manifestPath = new URL('assets/mail/manifest.json', root);
const manifest = {schema_version:1,scripts:[]};
if(process.argv.includes('--check'))Object.assign(manifest,JSON.parse(await fs.readFile(manifestPath,'utf8')));
for (const definition of definitions) {
  const config = '{'+Object.entries(definition).filter(([key])=>!['file','label','uuid'].includes(key)).map(([key,value])=>JSON.stringify(key)+':'+(typeof value==='function'?value.toString():JSON.stringify(value))).join(',')+'}';
  const providerHelpers=definition.provider==='qq_mail'?`const markQQMailRead=${markQQMailRead.toString()};\nconst qqPlainTextHTML=${qqPlainTextHTML.toString()};\nconst qqSendmailSid=${qqSendmailSid.toString()};\nconst qqTimeZone=${qqTimeZone.toString()};\n`:definition.provider==='gmail'?`const providerAccountDOM=${providerAccountDOM.toString()};\n`:'';
  const source = `// ==UserScript==\n// @name         App-CLI ${definition.label} Network Reader\n// @namespace    sparkclaw.local\n// @version      0.2.0\n// @description  Read observed email sources in the signed-in page; SparkClaw owns synchronization and durable receipts.\n${definition.origins.map(origin=>'// @match        '+origin+'/*').join('\n')}\n// @run-at       document-start\n// @grant        none\n// @noframes\n// ==/UserScript==\n\n// Generated by applications/mail/userscripts/build.mjs. Edit its source modules.\n(()=>{\nconst installOutlookOriginalResolver=${installOutlookOriginalResolver.toString()};\nconst installOutlookRangeTransport=${installOutlookRangeTransport.toString()};\nconst installOutlookEarlyBridge=${installOutlookEarlyBridge.toString()};\nconst parseGmailList=${parseGmailList.toString()};\nconst parseOutlookList=${parseOutlookList.toString()};\nconst parseQQMailList=${parseQQMailList.toString()};\n${providerHelpers}(${installReader.toString()})(${config});\n})();\n`;
  const destination = new URL('assets/mail/'+definition.file,root);
  const sha256 = crypto.createHash('sha256').update(source).digest('hex');
  if(process.argv.includes('--check')) {
    if(await fs.readFile(destination,'utf8')!==source||!manifest.scripts.some(s=>s.file===definition.file&&s.sha256===sha256))throw new Error('managed mail script is stale: '+definition.file);
  } else {
    await fs.writeFile(destination,source);
    const entry={file:definition.file,version:'0.2.0',sha256,requires:[],uuid:definition.uuid};
    const index=manifest.scripts.findIndex(s=>s.file===definition.file);
    if(index<0)manifest.scripts.push(entry);else manifest.scripts[index]=entry;
  }
}
if(!process.argv.includes('--check'))await fs.writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n');
